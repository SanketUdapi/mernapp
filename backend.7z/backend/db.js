const mongoose = require("mongoose");
require("dotenv").config();

module.exports = async () => {
    try {
        await mongoose.connect(
            `mongodb+srv://${process.env.MONGO_NAME}:${process.env.MONGO_PASSWORD}@crudapp.eqf4a.mongodb.net/CrudApp?retryWrites=true&w=majority`
        );
        console.log("Connected to database.");
    } catch (error) {
        console.log("Could not connect to database.", error);
    }
};